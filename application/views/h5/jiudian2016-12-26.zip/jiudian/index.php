<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
        <link rel="manifest" href='<?php echo base_url("jiudian_data/manifest.json"); ?>'/>

        <link href='<?php echo base_url("jiudian_lib/ionic/css/ionic.min.css"); ?>' rel="stylesheet">

        <script src='<?php echo base_url("jiudian_js/jquery-3.1.1.min.js"); ?>'></script>
        <script src='<?php echo base_url("jiudian_lib/ionic/js/ionic.bundle.min.js"); ?>'></script>

        <!--新加-->
        <script src='<?php echo base_url("jiudian_js/config.js"); ?>'></script>

        <script src='<?php echo base_url("jiudian_js/app.js"); ?>'></script>
        <script src='<?php echo base_url("jiudian_js/controllers.js"); ?>'></script>
        <script src='<?php echo base_url("jiudian_js/services.js"); ?>'></script>

        <link href='<?php echo base_url("jiudian_css/style.css"); ?>' rel="stylesheet">
        <link href='<?php echo base_url("jiudian_css/icomoon.css"); ?>' rel="stylesheet">

        <!--新加-->
        <link href='<?php echo base_url("css/common.css"); ?>' rel="stylesheet"/>
        <link type="text/css" href='<?php echo base_url("css/publicCss1.css"); ?>' rel="stylesheet" />
        <script src='<?php echo base_url("js/publicJS.js"); ?>'></script>
        <script type="text/javascript">
            function getCsrf() {
                var name = 'csrf_cookie_name';
                var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
                if (arr != null){
                    return unescape(arr[2]);
                }
                return null;
            }

            function objtops(obj)
            {
                var p = [];
                for (var key in obj) {
                    p.push(key + '=' + encodeURIComponent(obj[key]));
                }
                return p.join('&');
            }
        </script>

    </head>
    <body ng-app="starter">
      <!--<ion-nav-view></ion-nav-view>-->
    <ion-nav-view animation="slide-left-right-ios7"></ion-nav-view>
</body>
<script type="text/javascript">
    var time = <?php echo $time; ?>;
</script>
</html>

