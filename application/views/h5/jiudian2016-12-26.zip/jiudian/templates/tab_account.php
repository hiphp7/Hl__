<ion-view view-title="" hide-nav-bar="true">
    <ion-content style="background-image:url('<?php echo base_url("jiudian_img/wdddbg.jpg"); ?>')">
        <div class="row" style="background-color: #11C1F3;">
            <div class="col ">
                <a  style="padding-left: 12px;" ng-click="backto()"><i class="icon ion-ios-arrow-left"></i></a>
                <span style="color: white;padding-left: 112px;font-size:17px">酒店订单</span>
            </div>
        </div>
        <div class="row"  style="margin-top: 12px;">
            <div class="col" style="padding:0">
                <a href="#/dash/hotels/{{hotel.id}}/tjdd/zxf/ddxq"><img src='<?php echo base_url("jiudian_img/wddd1.jpg"); ?>' style="width:100%"></a>
            </div>
        </div>
        <div class="row" style="margin-top: -10px;">
            <div class="col" style="padding:0">
                <img src='<?php echo base_url("jiudian_img/wddd2.png"); ?>' style="width:100%"></a>

            </div>
        </div>


    </ion-content>
</ion-view>
