<ion-view view-title="在线支付" style="background-color:#EFEFEF">
    <ion-content>
        <div style="background-color: #11c1f3;height: 40px;padding-top: 8px">
            <a ng-click="goto2()" style="border: 0; text-align: center;">
                <i class="icon ion-chevron-left" style="color:white;font-size: 25px;margin-top: 12px;margin-left: 10px"></i>
                <span style="font-weight: bold;color: white;font-size: 20px; margin-left: 32%">在线支付</span>
            </a>
        </div>
        <div class="row" style="padding:0">
            <div class="col" style="padding:0">
                <div class="list">
                    <a class="item item-icon-right" href="#" style="padding:5px;border-width:0 0 1px 0">
                        <h2 style="font-size:20px">北京大方饭店</h2>
                        <p style="font-size:10px;margin-bottom:0px">标准间预付</p>
                        <p style="font-size:10px">11-24入住，11-28离店，预定1间房</p>
                        <p style="font-size:10px">应付金额: ￥ <em style="font-size:15px;color:red;">1184</em>.00</p>


                        <!-- <div class="col col-20 col-offset-80">
                          <p style="font-size:12px;color:blue">详情</p>
                          <i class="item item-icon-right ion-ios-arrow-down"></i>
                        </div> -->

                    </a>
                </div>
            </div>
        </div>
        <div class="row" style="padding:10px">
            <div class="col">


                <a href="#/dash/hotels/{{hotel.id}}/tjdd/zxf/ddxq"> <img src='<?php echo base_url("jiudian_img/zffs.jpg"); ?>' style="width:100%"></a>


            </div>
        </div>

    </ion-content>
</ion-view>
