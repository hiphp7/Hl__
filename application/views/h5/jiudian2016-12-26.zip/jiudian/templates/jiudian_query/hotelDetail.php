<ion-view view-title="酒店详情">
    <a ng-click="back()"><img src='<?php echo base_url("jiudian_img/fanhui.png"); ?>' style="z-index: 99;position: absolute; width: 15%;"></a>
    <a ><img src='<?php echo base_url("jiudian_img/shoucang.png"); ?>' style="z-index: 99;position: absolute; width: 15%;left: 80%"></a>
    <ion-content>
        <ion-slide-box slide-interval="5000" does-continue="true" auto-play="true" show-pager="true">
            <ion-slide>
                <div class="box"><img src ='<?php echo base_url("jiudian_img/zs.jpg"); ?>' style="width:100%;height:160px"></div>
            </ion-slide>
            <ion-slide>
                <div class="box "><img src ='<?php echo base_url("jiudian_img/zs1.jpg"); ?>' style="width:100%;height:160px"></div>
            </ion-slide>
            <ion-slide>
                <div class="box "><img src = '<?php echo base_url("jiudian_img/zs2.jpg"); ?>' style="width:100%;height:160px"></div>
            </ion-slide>
            <ion-slide>
                <div class="box "><img src = '<?php echo base_url("jiudian_img/zs3.jpg"); ?>' style="width:100%;height:160px"></div>
            </ion-slide>
            <ion-slide>
                <div class="box "><img src = '<?php echo base_url("jiudian_img/zs4.jpg"); ?>' style="width:100%;height:160px"></div>
            </ion-slide>

        </ion-slide-box>

        <div class="list" style="margin-bottom:0">
            <div class="item item-icon-right" style="padding:5px;border-width:0 0 1px 0;font-size: 1.3rem;">
                <span class="calm" ng-bind="selected_hotel.commentScore"></span>
                <span class="calm" style="margin-left:0.1rem;">分</span>
                <span style="margin-left:0.2rem;color:#999999;" ng-bind='selected_hotel.commentScore >= 4.5 ? "服务好评": "服务一般"'></span>
                <span style="margin-left:0.3rem;color:#999999;" ng-bind='selected_hotel.category | xingji'></span>
            </div>
            <a class="item" style="padding:5px;border-width:1px 0 1px 0">
                <h2 style="font-size: 13px;" ng-bind='selected_hotel.address'></h2>
                <p style="font-size: 12px;" ng-bind='selected_hotel.description'></p>
            </a>
            <div class="item item-divider" style="min-height:10px;background-color: #efefef;"></div>
            <a class="item item-icon-left">
                <i class="icon ion-ios-list-outline"></i>
                11月10日-11月11日
            </a>
            <a class="item item-icon-right" style="padding:0px;border-width:0 0 1px 0">
                <img src='<?php echo base_url("jiudian_img/fuwu.jpg"); ?>' style="width:100%;">
            </a>
        </div>
        <div class="row" style="padding:0;background-image:url('<?php echo base_url("jiudian_img/jdydbj.jpg"); ?>')" >
            <div class="col" style="padding:0;">

                <div ng-click="show=!show">
                    <img src='<?php echo base_url("jiudian_img/swsrf.jpg"); ?>' style="width:100%">
                </div>
                <div ng-show="show" >
                    <a href="#/dash/hotels/{{hotel.id}}/tjdd"><img src='<?php echo base_url("jiudian_img/zxcdhyj.jpg"); ?>' style="width:95%;float:right;margin-top: -5px"></a>
                    <img src='<?php echo base_url("jiudian_img/zxyfzkj.jpg"); ?>' style="width:95%;float:right">
                    <img src='<?php echo base_url("jiudian_img/jdbzsj.jpg"); ?>' style="width:95%;float:right">
                </div>
            </div>
        </div>
        <div class="row" style="padding:0">
            <div class="col" style="padding:0;">
                <img src='<?php echo base_url("jiudian_img/swsrf1.jpg"); ?>' style="width:100%">
            </div>
        </div>
        <div class="row" style="padding:0">
            <div class="col" style="padding:0;">
                <img src='<?php echo base_url("jiudian_img/hxdcf.jpg"); ?>' style="width:100%">
            </div>
        </div>

        <div class="row" style="padding:0">
            <div class="col" style="padding:0;">
                <img src='<?php echo base_url("jiudian_img/swsrf3.jpg"); ?>' style="width:100%">
            </div>
        </div>
        <div class="row" style="padding:0">
            <div class="col" style="padding:0;">
                <button class="button button-full button-light" style="margin:0;min-height:0;min-width:0">
                    查看全部
                </button>
            </div>
        </div>

        <div class="row" style="padding:0">
            <div class="col">
                <img src='<?php echo base_url("jiudian_img/zccr.jpg"); ?>' style="width:100%">
            </div>
        </div>

    </ion-content>
</ion-view>
