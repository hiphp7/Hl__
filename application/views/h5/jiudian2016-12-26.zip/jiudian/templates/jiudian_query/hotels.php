<ion-view view-title="酒店" hide-nav-bar="true">
    <style type="text/css">
        .jiudian_list{
            border: none;
            padding: 0;
        }
        .jiudian_list img{
            width:30%;height:12rem;float:left;
        }
        .jiudian_list .contentBox{
            height:12rem;border-top:1px solid #ddd;
        }
        .jiudian_list .contentBox ul{
            float:left;width:70%;height:100%;overflow: hidden;padding: 1rem 0.5rem 0.5rem 1rem;
        }
        .jiudian_list .contentBox ul .li3 .describe{
            width:90%;
            height:auto;
            line-height: 130%;
            white-space:normal;
            /*            display:-moz-box;
                        display:-webkit-box;
                        display:box;
                        -moz-box-orient:vertical;
                        -webkit-box-orient:vertical;
                        box-orient:vertical;
                        -moz-line-clamp:2;
                        -webkit-line-clamp: 2;
                        line-clamp:2;
                        overflow: hidden;*/
        }

        .jiudian_list .item-content{
            padding:0;
        }
    </style>
    <ion-content>
        <section style="padding-bottom:5rem;">
            <div class="row" style="background-color: #11C1F3;">
                <div class="col col-10">
                    <a style="padding-left: 12px;position: relative;" ng-click="back();">
                        <i class="icon ion-chevron-left" style="color: white;font-size:160%;position: absolute;top:50%;margin-top: -1.138rem;"></i>
                    </a>
                </div>
                <div class="col col-90" style="padding-left: 10px;position: relative;">
                    <label class="item-input-wrapper" style="background-color: #FFFFFF;position: absolute;top:50%;margin-top: -1.138rem;width: 95%;"> 
                        <input type="search" placeholder="酒店名/商圈/地标/景点等" ng-model="searchContent" style="background-color: white;width: 290px;height:24px;">
                    </label>
                </div>
            </div>
            <div class="row">
                <div class="col col-25">
                    <button class="button button-small button-light" ng-click="show=!show" style="padding-left: 0px;padding-top: 9px;border:0">
                        低价优先<i class="icon ion-ios-arrow-down" style="padding: 6px;"></i>
                    </button>
                </div>
                <div class="col col-25">
                    <button class="button button-small button-light" style="padding-left: 0px;padding-top: 9px;border:0">
                        商圈区域<i class="icon ion-ios-arrow-down" style="padding: 6px;"></i>
                    </button>
                </div>
                <div class="col col-25">
                    <button class="button button-small button-light" style="padding-left: 0px;padding-top: 9px;border:0">
                        不限<i class="icon ion-ios-arrow-down" style="padding: 6px;"></i>
                    </button>
                </div>
                <div class="col col-25">
                    <button class="button button-small button-light" style="padding-left: 0px;padding-top: 9px;border:0">
                        设施服务<i class="icon ion-ios-arrow-down" style="padding: 6px;"></i>
                    </button>
                </div>
            </div>
            <div class="row" style="padding:0" ng-show="show"> 
                <div class="col">
                    <div class="list">

                        <a class="item item-icon-left" href="#">
                            <i class="icon ion-checkmark-round"></i>
                            低价有限
                        </a>

                        <a class="item item-icon-left item-icon-right" href="#">
                            <i class="icon "></i>
                            高价优先

                        </a>

                        <a class="item item-icon-left" href="#">
                            <i class="icon"></i>
                            好评优先

                        </a>

                    </div>
                </div>
            </div>

            <ion-list style="border-bottom:1px solid #ddd;">
                <ion-item class="jiudian_list" ng-repeat="hotel in hotels" ng-click="qiangding(hotel);">
                    <img ng-src="{{hotel.thumbnailId}}">
                    <div class="contentBox">
                        <ul>
                            <li class="li1 f_s13 fw_b" ng-bind='hotel.name'></li>
                            <li class="li2 f_s11">
                                <span class="calm" ng-bind='hotel.commentScore'></span>
                                <span class="calm" style="margin-left:0.2rem;">分</span>
                                <span class="calm ml_30" ng-bind='hotel.commentScore > 3.5 ? "好": "一般"'>好</span>
                                <span class=" ml_30 mr_30"  style="color:#8B8B8B;">|</span>
                                <span style="color:#8B8B8B;">豪华型</span>
                            </li>
                            <li class="li3 f_s11" style="line-height: 85%;color:#8B8B8B;">
                                <span class="describe" ng-bind="hotel.description | cut:30:' ...'"></span>
<!--                                <span class="ml_30 mr_30">|</span>
                                <span>距您455m</span>-->
                            </li>
                            <li class="li4" style="height:auto;margin-top: 1rem;">
                                <span style="color:#FF6600;float:left;" ng-bind='"￥" + hotel.salePrice'>￥788元</span>
                                <input name="" type="button" value="抢订" style="background-color:#FF6600;color:#fff;padding:0.2rem 1.5rem;border-radius: 0.3rem;float:right;margin-right: 1rem;">
                            </li>
                        </ul>
                    </div>
                </ion-item>
            </ion-list>
        </section>
    </ion-content>
</ion-view>
