<!--
  This template loads for the 'tab.friend-detail' state (app.js)
  'friend' is a $scope variable created in the FriendsCtrl controller (controllers.js)
  The FriendsCtrl pulls data from the Friends service (service.js)
  The Friends service returns an array of friend data
-->
<ion-view view-title="{{chat.name}}"hide-nav-bar="true">
  <ion-content>
  <div class="row" style="background-color: #11C1F3;">
	   <div class="col ">
	   <a style="padding-left: 12px;" ng-click="backto()"><i class="icon ion-ios-arrow-left" style="color: white;font-size:115%"></i></a>
	   <span style="color: white;padding-left: 112px;font-size:17px">订单详情</span>
	   </div>
	 </div>
      <img src='<?php echo base_url("jiudian_img/ddxq.jpg"); ?>' style="width: 100%;">
    <div class="list">

 
 
    </div>
    <div class="row" style="padding:0">
    <div class="col">
   <img src='<?php echo base_url("jiudian_img/ddxq1.jpg"); ?>' style="width:100%">
	</div>
	</div>
  <div class="row">
     <div class="col col-33 col-offset-33">
	 
	 
	 <button class="button button-light">
 <p style="color:#49D3DD"> 投诉 建议</p>
</button>

	 </div>
	      <div class="col col-33 ">
	 
	 
	 <button class="button button-light">
 <p style="color:#49D3DD"> 取消订单</p>
</button>
	 </div>
	 </div>
	 <div class="row">
	   <div class="col">
	      <img src='<?php echo base_url("jiudian_img/mskz.png"); ?>' style="width:100%">
		</div>
	 </div>
	<div class="row">
	   <div class="col col-33">
	       <a href="#" style="text-decoration: none;"><img src='<?php echo base_url("jiudian_img/fjp.png"); ?>' style="width:100%"><p style="text-align: center;color:black">飞机票</p></a>
		</div>
		<div class="col col-33">
	       <a href="#" style="text-decoration: none;"><img src='<?php echo base_url("jiudian_img/hcp.png"); ?>' style="width:100%"><p style="text-align: center;color:black">火车票</p></a>
		</div>
		<div class="col col-33">
	       <a href="#" style="text-decoration: none;"><img src='<?php echo base_url("jiudian_img/kf.png"); ?>' style="width:100%"><p style="text-align: center;color:black">咨询</p></a>
		</div>
	</div>
		
	
  </ion-content>
</ion-view>
