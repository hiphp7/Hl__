<ion-view view-title="国内/国外酒店" >
    <style type="text/css">
        .modal-backdrop-bg {
            background-color:rgba(0,0,0,0.4);
        }
        .starBox .child{
            padding:0;color: #8E8E8E;
        }
        .starBox .child label{
            width:100%;text-align:center;min-height:0;min-width:0;
            line-height:22px;font-size:13px;border: 1px solid #8E8E8E;
            padding: 0.4rem 1.4rem;display: inline-block;margin-top: 10px;margin-bottom: 10px;
        }
        .starBox .child label.on{
            border: 1px solid #42D6D4;color:#42D6D4;
        }
    </style>
    <script type="text/javascript">
        //选中不限时其它取消选中

        $(document).on("change", ".starBox .noLimit input[type='checkbox']", function() {
            alert($(this).prop("checked"));
            if ($(this).prop("checked") == true) {
                $(this).parent().addClass("on");
                $(this).attr("disabled", "disabled");
                $('.starBox .starChild').find("input[type='checkbox']").prop("checked", false);
                $('.starBox .starChild').find('label').removeClass("on");
            }
            
        });
        $(document).on("change", ".starBox .starChild input[type='checkbox']", function() {
            alert($(this).prop("checked"));
            if ($(this).prop("checked") == true) {
                $(this).parent().addClass("on");
                $('.starBox .noLimit').find("input[type='checkbox']").prop("checked", false).removeAttr("disabled").parent().removeClass("on");
            }
            var nsijr = $(this).parent().parent().parent().parent().find("input[type='checkbox']:checked").length;
            if (nsijr == 0) {
                $(this).parent().parent().parent().parent().find("li:first input[type='checkbox']").prop("checked", true).attr("disabled", "disabled");
            }
        });
    </script>
    <ion-content style="background-color: #EFEFEF;" >
        <div style="background-color: #11c1f3;height: 40px;padding-top: 8px">
            <a ng-href="#/bibi" style="border: 0; text-align: center; text-decoration: none;">
                <i class="icon ion-chevron-left" style="color:white;font-size: 25px;margin-top: 12px;margin-left: 10px"></i>
                <b style="font-weight: bold;color: white;font-size: 20px; margin-left: 24%">国内/国外酒店</b>
            </a>
        </div>
        <ion-slide-box slide-interval="5000" does-continue="true" show-pager="false">
            <ion-slide>
                <div class="box"><img src ='<?php echo base_url("jiudian_img/sdlj.jpg"); ?>' style="width:100%;height:200px;margin-top:-42px;"></div>
            </ion-slide>
            <ion-slide>
                <div class="box "><img src ='<?php echo base_url("jiudian_img/bibilx.jpg"); ?>' style="width:100%;height:200px;margin-top:-42px"></div>
            </ion-slide>
        </ion-slide-box>
        <div class="row padding">
            <div class="col col-50" style="padding:0px">
                <button class="button button-light button-full" style="margin-top:-18px;border-radius: 5px 0 0 5px; border-bottom: 2px solid #17CECC">
                    <span> 国内酒店</span>
                </button>

            </div>
            <div class="col col-50" style="padding:0px">
                <button class="button button-light button-full" style="margin-top:-18px;border-radius: 0 5px 5px 0;"  ng-click="show=!show">
                    <span>海外酒店</span>
                </button>
            </div>
        </div>
        <div class="row padding" style="border-radius: 5px 0 0 5px">
            <div class="col">
                <div class="list">

                    <a class="item item-icon-right" style="padding:5px;border-width:0 0 1px 0" ng-click="placeAction('出发地')">
                        <p style="font-size:1.3rem">目的地城市</p>
                        <h2 style="font-size:2.2rem" ng-bind="cityName"></h2>

                    </a>
                    <a class="item item-icon-right" style="padding:5px;border-width:1px 0 1px 0">
                        <div  class="row">
                            <div class="col col-40" ng-click="showDatePage('left')">
                                <p style="font-size:1.3rem">入住日期</p>
                                <h2 style="font-size:1.6rem" ng-bind="ruzhuDate | date:'MM月dd日 '"></h2>
                            </div>
                            <div class="col col-20" style="padding:0">
                                <h2 style="font-size:1.3rem;padding-top: 1rem;color: #11C1F3" ng-bind="'共' + dayNumber + '天'"></h2>
                            </div>
                            <div class="col col-40" ng-click="showDatePage('right')">
                                <p style="font-size:1.3rem">离店日期</p>
                                <h2 style="font-size:1.6rem" ng-bind="lidianDate | date:'MM月dd日 '"></h2>
                            </div>
                        </div>
                    </a>

                    <a class="item  item-icon-right"  style="padding:5px;border-width:1px 0 1px 0">
                        <input  type="text" placeholder="请输入酒店名/商圈/地标/景点等相关地点" ng-model="jiudian_search.jiudianming" style="height:4.4rem;width:100%">
                    </a>
                    <a class="item item-icon-right"  style="padding:5px;border-width:1px 0 1px 0" ng-click="modal.show()">
                        <div class="col col-50" style="position: relative;float:left">
                            <label class="item item-input item-select" style="font-size:1.3rem;border-width:0px;">
                                <div class="input-label" style="font-size:1.3rem;">
                                    <h3>星级</h3>
                                </div>
                            </label>
                        </div>

                        <div class="col col-50" style="position: relative;float:right">
                            <label class="item item-input item-select" style="font-size:11px;border-width:0px;">
                                <div class="input-label">
                                    <h3>价格</h3>
                                </div>
                            </label>
                        </div>

                    </a>
                    <script id="templates/modal.html" type="text/ng-template">
                        <ion-modal-view style="top:34%;width: 100%;left: 0px;height: 50%;">
                            <ion-content class="padding">
                                <div class="row" style="padding:0">
                                    <div class="col col-20 col-offset-80">
                                        <a  ng-click="modal.hide()"  style="display: block;position: relative;float: right;"> <i class="icon ion-close-circled"></i></a>
                                    </div>
                                </div>
                                <div class="row" style="padding:0">
                                    <div class="col col-50" style="padding:0">
                                        <span>价格</span>

                                    </div>
                                    <div class="col col-50"style="padding:0">
                                        <span style="float: right;color:#17CECC">不限</span>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col col-20" style="padding:0">

                                        <p style="text-align: center;">￥0</p>

                                    </div>
                                    <div class="col col-20" style="padding:0">
                                        <p style="text-align: center;">￥200</p>

                                    </div>
                                    <div class="col col-20" style="padding:0">
                                        <p style="text-align: center;">￥400</p>

                                    </div>
                                    <div class="col col-20" style="padding:0">
                                        <p style="text-align: center;">￥600</p>

                                    </div>
                                    <div class="col col-20" style="padding:0">

                                        <p style="text-align: center;">不限</p>


                                    </div>

                                </div>
                                <div class="row" style="padding:0">
                                    <div class="col" style="padding:0">
                                        <div class=" range range-calm" style="border-width:0">

                                            <input type="range" name="volume">

                                        </div>
                                    </div>
                                </div>

                                <div class="row" style="margin-top: -7px;padding:0">
                                        <div class="col" style="padding:0">
                                                <span>星级(多选)</span>
                                        </div>
                                </div>
                                
                                <div class="starBox">
                                        <div class="row" style="padding:0">
                                                <div class="col child noLimit">
                                                    <label class="on" for="checkbox-vd-1" ng-click="chkStar(true)">
                                                        不限<input type="checkbox" id="checkbox-vd-1" class="regular-checkbox ryuaibnsbox yuainsbt" disabled="disabled" ng-bind="chkAll_star" ng-checked="chkAll_star" />
                                                    </label>
                                                </div>
                                                <div class="col child starChild" style="margin: 0 0.8rem;">
                                                    <label for="checkbox-vd-2" ng-click="chkStar(false)">
                                                        经济连锁<input type="checkbox" id="checkbox-vd-2" class="regular-checkbox" ng-model="x.chk" />
                                                    </label>
                                                </div>
                                                <div class="col child starChild">
                                                    <label for="checkbox-vd-3" ng-click="chkStar(false)">
                                                        酒店公寓<input type="checkbox" id="checkbox-vd-3" class="regular-checkbox" ng-model="x.chk" />
                                                    </label>
                                                </div>
                                        </div>
                                        <div class="row" style="padding:0">
                                                <div class="col child starChild">
                                                    <label for="checkbox-vd-4" ng-click="chkStar(false)">
                                                        三星/舒适<input type="checkbox" id="checkbox-vd-4" class="regular-checkbox" ng-model="x.chk" />
                                                    </label>
                                                </div>
                                                <div class="col child starChild" style="margin: 0 0.8rem;">
                                                    <label for="checkbox-vd-5" ng-click="chkStar(false)">
                                                        四星/高档<input type="checkbox" id="checkbox-vd-5" class="regular-checkbox" ng-model="x.chk" />
                                                    </label>
                                                </div>
                                                <div class="col child starChild">
                                                    <label for="checkbox-vd-6" ng-click="chkStar(false)">
                                                        五星/豪华<input type="checkbox" id="checkbox-vd-6" class="regular-checkbox" ng-model="x.chk" />
                                                    </label>
                                                </div>
                                        </div>
                                </div>

                                <button class="button button-block" style="background:#FF6600;color:#fff;font-size:1.8rem;">
                                    确定
                                </button>
                            </ion-content>
                        </ion-modal-view>
                    </script>
                    <a class="item item-icon-right"  style="padding:5px;border-width:1px 0 1px 0"  ng-show="show">
                        <div class ="row">
                            <div class="col col-10" style="position: relative;float:left"> 		 
                                <label class="item item-input item-select" style="font-size:11px;border-width:0px;padding-left: 2px">
                                    <div class="input-label">
                                        <h3 style="font-size:13px">1位</h3>
                                    </div>

                                </label> 
                            </div>

                            <div class="col col-50" style="position: relative;float:left"> 		 
                                <label class="item item-input item-select" style="font-size:11px;border-width:0px;">
                                    <div class="input-label">
                                        <h3 style="font-size:13px">成人</h3>
                                    </div>
                                    <select style="padding-left:0;padding-right:30px">
                                        <option selected>0位</option>
                                        <option >五星/豪华</option>
                                        <option>四星</option>
                                    </select>
                                </label> 
                            </div>
                            <div class="col col-15" style="position: relative;float:left"> 		 
                                <label class="item item-input " style="font-size:11px;border-width:0px;">
                                    <div class="input-label">
                                        <h3 style="font-size:13px">儿童</h3>
                                    </div>

                                </label> 
                            </div>
                            <div class="col col-35" style="position: relative;float:left"> 
                                <label class="item item-input " style="font-size:11px;border-width:0px;">
                                    <div class="input-label">
                                        <h3 style="font-size:13px">每间人数</h3>
                                    </div>

                                </label> 
                            </div>
                        </div>
                    </a>
                    <button class="button button-block" style="color:#fff;background:#FF6600;margin-top:-1px;margin-bottom:-1px" ng-click="search();">
                        搜索查询
                    </button>

                </div>
            </div>
        </div>
        <div class="row padding" style="background-color: white;padding-left: 19px;">
            <div class="col col-50">
                <a  style="text-decoration:none"><span><img src='<?php echo base_url("jiudian_img/fjp1.png"); ?>' style="width:30%;margin-left: 25px;">飞机票</span></a>
            </div>
            <div class="col col-50" >
                <a  style="text-decoration:none"><span><img src='<?php echo base_url("jiudian_img/hcp1.png"); ?>' style="width:30%;margin-left: 25px;">飞机票	</span></a>
            </div>
        </div>
        <div class="row padding" style="margin-top: 10px;">
            <div class="col">
                <img src ='<?php echo base_url("jiudian_img/why.jpg"); ?>' style="width:100%;height:260px">
            </div>
        </div>
    </ion-content>
</ion-view>
