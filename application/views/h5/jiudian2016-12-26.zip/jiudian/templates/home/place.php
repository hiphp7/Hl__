<style type="text/css">
    .place_head .header {
    height: 44px;
    line-height: 44px;
    }
    .alpha_sidebar{
        position: absolute;
        /*top:90px;*/
        top: 90px;
        right:  10px;
        z-index: 100000
    }
    .alpha_sidebar li{
        color: #49afcd;
        margin-bottom: 2px;
        cursor: pointer;
    }
    .alpha_list{
        padding-right: 22px;
    }

    .bar-subheader .item-input{
        padding-left:24px;
        padding-top:2px;
    }
    .bar-subheader .item-input i{
        font-size:139%;
    }
    .bar-subheader .item-input input{
        font-size:16px;
    }
    .padding {
        padding-top: 0px;
    }
    .returnbut {
        position: absolute;
        left: 1rem;
        top: 50%;
        margin-top: -1.138rem;
        height: 2.277rem;
        line-height: 2.277rem;
        font-size: 1.6rem;
    }
    .alpha_list .item {
        border-color: #ddd;
        background-color: #fff;
        color: #444;
        position: relative;
        z-index: 2;
        display: block;
        margin: -1px;
        padding: 16px;
        border-width: 1px;
        border-style: solid;
        font-size: 16px;
    }
    .alpha_list .item-divider {
        padding-top: 8px;
        padding-bottom: 8px;
        min-height: 30px;
        background-color: #f5f5f5;
        color: #222;
        font-weight: 500;
    }
</style>
<ion-view>
    <ion-header-bar class="bar-positive place_head">
        <div class="header po_re f_s18 text_a_c border_b_1_d bg_fff pftop">
            <span class="heaTxx">选择城市</span>
            <a class="returnbut c_fff f_s18 returnjs" ng-click="back();"><span></span>返回</a>
        </div>
    </ion-header-bar>

    <div class="bar bar-subheader">
        <label class="item-input" style="">
            <i class="icon ion-ios-search placeholder-icon"></i>
            <input type="search"  style="" placeholder="搜索" ng-focus="searchCity($event)" ng-keyup="keyup($event)" ng-model="content">
        </label>
    </div>
    <ion-content scroll="true" class="has-header ng-hide searchList" padding="true"  style="top:100px" ng-show="content !='' " >
        <div data-ng-repeat="x in searchList">
            <ion-item ng-click="showHomePage(x)">
                {{x.cityName}}
            </ion-item>
        </div>
    </ion-content>
    <ion-content scroll="true" class="has-header ng-hide" padding="true" style="position: absolute;top:100px;" ng-show="content ==''"  >
        <div data-ng-repeat="(letter, authors) in sorted_users" class="alpha_list">
            <ion-item class="item item-divider" id="index_{{letter}}">
                {{letter}}
            </ion-item>
            <ion-item ng-repeat="author in authors" ng-bind="author.cityName" ng-click="showHomePage(author)">
            </ion-item>
        </div>
    </ion-content>

    <ul class="alpha_sidebar ng-hide"   ng-show="content =='' ">
        <li ng-click="gotoList('index_{{letter}}')" ng-repeat="letter in alphabet"> 
            {{letter}}
        </li>
    </ul>
</ion-view>