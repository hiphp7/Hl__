<ion-view>
    <style type="text/css">
        .c_49D3DD{ color: #49D3DD;}
        .c_5f5f5f{color: #5f5f5f;}
        .datetable .on2, .datetable .on2 p{color:#fff; background:#49D3DD;}
    </style>
    <ion-header-bar align-title="center" style="background-color: #49D3DD;">
        <a class="button icon-left ion-ios-arrow-left button-clear" style="color:#fff;" ng-click="back()"></a>
        <h1 class="title light">{{title}}</h1>
    </ion-header-bar>
    <ion-content>

        <!-----日历------->
        <div>
            <ul class="dateUlbox text_a_c">
                <li ng-repeat="x in dateLists">
                    <p class="f_s18 text_a_c mb_55 border_b_1_d pb_55" ng-bind="x.date| date:'yyyy年MM月'"></p>
                    <ul class="datetablego c_1d1d1d f_s14 wrapfix fw_b">
                        <li class="c_49D3DD">日</li>
                        <li>一</li>
                        <li>二</li>
                        <li>三</li>
                        <li>四</li>
                        <li>五</li>
                        <li>六</li>
                    </ul>
                    <ul class="datetable c_5f5f5f wrapfix">
                        <li ng-repeat="y in x.days" class="{{y.enable}}" style="padding-top: 0;height: 4.6rem;line-height: 4.6rem;">
                            <div ng-switch on="y.enable">
                                <!-- 不可用状态 -->
                                <div ng-switch-when="false" class="c_808080"><p class="f_s14" style="height:4.6rem;line-height: 4.6rem;" ng-bind="y.solar| date:'dd'"></p></div>
                                <!-- 可用状态 周末-->
                                <div ng-show="true" ng-switch-when="true" ng-click="showHomePage(y)" style="position: relative;"><div id="inOrOut" class="f_s10" style="position: absolute;top:0;left:0;color:red;"></div><p class="f_s14 as" ng-class="loadClass(y, 2)" style="height:4.6rem;line-height: 4.6rem;font-weight:bold;" ng-bind="y.solar| date:'dd'"></p></div>
                            </div>
                        </li>
                    </ul>
                </li>

            </ul>
        </div>

    </ion-content>

</ion-view>
<script type="text/javascript">
    $(function(){
        //$("#inOrOut").text("入住");
    });
    
</script>