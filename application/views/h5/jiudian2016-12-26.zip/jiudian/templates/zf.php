<!--
  This template loads for the 'tab.friend-detail' state (app.js)
  'friend' is a $scope variable created in the FriendsCtrl controller (controllers.js)
  The FriendsCtrl pulls data from the Friends service (service.js)
  The Friends service returns an array of friend data
-->
<ion-view view-title="预定支付">
  <ion-content>
  
      <img src='<?php echo base_url("jiudian_img/zxf.jpg"); ?>' style="width: 100%; height: 170px">
   <div class="list card" style="margin:0">
   <div class="item item-divider" style="min-height:10px"></div>
  <a href="#" class="item item-icon-right">
     <p>房间数</p>
	 
   <i class="icon ion-ios-arrow-down"></i>
  </a>

 <a href="#" class="item item-icon-right">
     <p>入住人</p>
	 
   <i class="icon"><img src='<?php echo base_url("jiudian_img/rzrs.png"); ?>' style="height: 30px;width: 30px;"></i>
  </a>

  <a href="#" class="item item-icon-right">
     <p>境内电话</p>
	 
   <i class="icon"> <img src='<?php echo base_url("jiudian_img/jndh.png"); ?>' style="height: 30px;width: 30px;"></i>
  </a>
  <div class="item item-divider" style="min-height:10px"></div>
  <h2 style="font-size:14px;margin-bottom:5px;margin-top:5px">超值套餐</h2>
  <a href="#" class="item item-avatar item-icon-right">
    <img src='<?php echo base_url("jiudian_img/cztc.png"); ?>'>
	<h2>立减40元接送机优惠卷</h2>
     <p>￥8/1张</p>
   <i class="icon"><img src='<?php echo base_url("jiudian_img/+-.png"); ?>' style="width: 91px;height: 38px;"></i>
  </a>  <a href="#" class="item item-avatar item-icon-right">
    <img src='<?php echo base_url("jiudian_img/cztc.png"); ?>'>
	<h2>立减50元接送站优惠卷</h2>
     <p>￥8/1张</p>
   <i class="icon"><img src='<?php echo base_url("jiudian_img/+-.png"); ?>' style="width: 91px;height: 38px;"></i>
  </a>
  <div class="item item-divider" style="min-height:10px"></div>
  <a href="#" class="item item-icon-right">
     <p>优惠卷</p> 
   <i class="icon ion-ios-arrow-right"></i>
  </a>
  <a href="#" class="item item-icon-right">
     <p>发票</p>	
   <i class="icon ion-ios-arrow-right"></i>
  </a>
</div>

    <div class="row" style="padding:0">
	<div class="col" style="padding:0">
	 <img src='<?php echo base_url("jiudian_img/kksm.jpg"); ?>' style="width:100%"></a>
	 
	</div>
	</div>
	<div class="row" style="padding:0">
	<div class="col" style="padding:0">
	  <a href="#/tab/chats/{{chat.id}}/zf/ddxq"> <img src='<?php echo base_url("jiudian_img/zf1.jpg"); ?>' style="width:100%"></a>
	</div>
	</div>
	
	
  </ion-content>
</ion-view>

