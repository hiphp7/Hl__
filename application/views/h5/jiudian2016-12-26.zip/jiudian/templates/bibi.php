<ion-view view-title="首页">
  <ion-content >

<!--顶部 -->
<div class="bar bar-header bar-calm" id="top">
  <i class="icon icon-chat2" id="top_message"></i>
  <i class="icon icon-phone" id="top_phone"></i>
  <h1 class="title" style="font-family: 方正正大黑简体; font-size: 20px;margin-top: 5px">比比旅行</h1>
</div>

<!-- 爆款热卖-->


<!-- 滑块 -->
<div id="ion_scroll" ng-app="ionicApp">
  <ion-scroll  id="list">
    <!-- 自动轮播-->
    <div id="slide">
      <ion-slide-box active-slide="myActiveSlide"  on-slide-changed="slideHasChanged($index)"
                     auto-play="true" does-continue="true" slide-interval=2000 show-pager="true"
                     pager-click="pageClick(index)" active-slide="model.activeIndex" delegate-handle="delegateHandler">
        <ion-slide>
          <div class="slide_box_img"><img src='<?php echo base_url("jiudian_img/d1.png"); ?>' ></div>
        </ion-slide>
        <ion-slide>
          <div class="slide_box_img"><img src='<?php echo base_url("jiudian_img/d1.png"); ?>' ></div>
        </ion-slide>
        <ion-slide>
          <div class="slide_box_img"><img src='<?php echo base_url("jiudian_img/d1.png"); ?>' ></div>
        </ion-slide>
        <ion-slide>
          <div class="slide_box_img"><img src='<?php echo base_url("jiudian_img/d1.png"); ?>'></div>
        </ion-slide>
      </ion-slide-box>
    </div>

    <!--机票、火车票-->
    <div class="row" >
      <div class="col">
        <div class="col-demo"><a href="#"><img src='<?php echo base_url("jiudian_img/jp.png"); ?>' ></a><br/><span class="font">机票</span></div>
      </div>
      <div class="col">
        <div class="col-demo"><img src='<?php echo base_url("jiudian_img/hcp_2.png"); ?>'><br/><span class="font">火车票</span></div>
      </div>
      <div class="col">
        <div class="col-demo" ><a ng-href="#/tab/dash"><img src='<?php echo base_url("jiudian_img/jd.png"); ?>' ></a><br/><span class="font">酒店客栈</span></div>
      </div>
      <div class="col">
        <div class="col-demo"><img src='<?php echo base_url("jiudian_img/jnyj.png"); ?>'><br/><span class="font">锦囊游记</span></div>
      </div>
    </div>

    <div class="row">
      <div class="col">
        <div class="col-demo"><a href="#"><img src='<?php echo base_url("jiudian_img/zm.png"); ?>'></a><br/><span class="font">周末去玩</span></div>
      </div>
      <div class="col">
        <div class="col-demo"><img src='<?php echo base_url("jiudian_img/gny.png"); ?>'><br/><span  class="font">国内游</span></div>
      </div>
      <div class="col">
        <div class="col-demo"><img src='<?php echo base_url("jiudian_img/cjy.png"); ?>'><br/><span class="font">出境游</span></div>
      </div>
      <div class="col">
        <div class="col-demo"><img src='<?php echo base_url("jiudian_img/chwl.png"); ?>'><br/><span class="font">吃喝玩乐</span></div>
      </div>
    </div>

    <!-- 旅行优势、各国签证...-->
    <div class="row" style=" padding:1px;">
      <div class="col" id="col_1" >
        <img src='<?php echo base_url("jiudian_img/f1.png"); ?>' class="travel_img"  id="img_1">
      </div>

      <div class="col" id="col_2" >
        <img src='<?php echo base_url("jiudian_img/f2.png"); ?>' class="travel_img">
      </div>

      <div class="col" id="col_3" style="margin:0; padding: 0;">
        <img src='<?php echo base_url("jiudian_img/f3.png"); ?>' class="travel_img">
      </div>
    </div>
    <div class="row" style=" padding:0 1px 0 1px; margin-top: 0.2px">
      <div class="col" id="col_4" >
        <img src='<?php echo base_url("jiudian_img/f4.png"); ?>' class="travel_img" >
      </div>

      <div class="col" id="col_5">
        <img src='<?php echo base_url("jiudian_img/f5.png"); ?>' class="travel_img">
      </div>

      <div class="col" id="col_6">
        <img src='<?php echo base_url("jiudian_img/f6.png"); ?>' class="travel_img">
      </div>
    </div>


    <div id="kong"></div>
    <!--登录有礼 -->
    <div class="item item-divider">
      <b><span id="dlyl" >登录有礼</span></b>
      <a id="more" href="#">更多专享 ></a>
    </div>

    <div id="login_gift">
      <!-- 上下左右4条线-->
      <div id="top_border" ></div>
      <div id="bottom_border"></div>
      <div id="left_border"></div>
      <div id="right_border"></div>
      <!-- 左边部分-->
      <div id="left">
        <img src='<?php echo base_url("jiudian_img/h3.jpg"); ?>' class="login_img">
        <p class="font">首单送300比币</p>
        <img src='<?php echo base_url("jiudian_img/h5.jpg"); ?>' class="login_img">
        <p class="font">新人有礼</p>
      </div>

      <!-- 中间的立即登录-->
      <div id="login_icon">
        <img src='<?php echo base_url("jiudian_img/008.png"); ?>' id="login_img">
      </div>

      <!-- 右边部分-->
      <div id="right">
        <img src='<?php echo base_url("jiudian_img/h4.jpg"); ?>' class="login_img">
        <p class="font">登录好礼红包</p>
        <img src='<?php echo base_url("jiudian_img/h6.jpg"); ?>' class="login_img">
        <p class="font">签到有喜</p>
      </div>
    </div>

  </ion-scroll>
</div>


  </ion-content>
</ion-view>

<img src='<?php echo base_url("jiudian_img/a001.png"); ?>' id="img">
<!-- tabs选项卡-->
<div class="tabs tabs-icon-top" id="tab" >
  <a class="tab-item" href="#" style="margin-right: 10%; color: #49d3dd;" >
    <i class="icon icon-home"  style="font-size: 28px" ></i>
    <b style="font-size: 12px">首&nbsp;页</b>
  </a>
  <a class="tab-item" href="#" style="margin-left: 10%;" >
    <i class="icon icon-user" style="font-size: 28px"></i>
    <b style="font-size: 12px">我&nbsp;的</b>
  </a>
</div>
<script src='<?php echo base_url("jiudian_js/index_js.js"); ?>'></script>